# Unicode Character Database
# Date: 2019-09-11, 16:03:00 GMT [KW]
# © 2019 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use, see https://www.unicode.org/terms_of_use.html
#
# For documentation, see the following:
# NamesList.html
# UAX #38, "Unicode Han Database (Unihan)"
# UAX #44, "Unicode Character Database"
# UTS #51, "Unicode Emoji"
#
# The UAXes and UTS #51 can be accessed at https://www.unicode.org/versions/Unicode13.0.0/

This directory contains the preliminary data files under development
for the Unicode Character Database, for Version 13.0.0 of the Unicode Standard.
