Now baz/start_y.h
#include "../foo/y.h"
