Now bar/y.h
#include_next "y.h"

